<head>
    <title>adminDasboard</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('addash.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script src="jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
       
       google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);
            function drawChart() {
            var data = google.visualization.arrayToDataTable([

            ['Month','Number'],
            <?php $__currentLoopData = $chart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($chart->year == '2023'): ?>
            <?php switch($chart->month):
                case (1): ?>
                    ['January',<?php echo e($chart->sales); ?>],
                    <?php break; ?>

                <?php case (2): ?>
                    ['February',<?php echo e($chart->sales); ?>],
                    <?php break; ?>
                
                <?php case (3): ?>
                    ['March',<?php echo e($chart->sales); ?>],
                    <?php break; ?>

                <?php case (4): ?>
                    ['April',<?php echo e($chart->sales); ?>],
                    <?php break; ?>
                
                <?php case (5): ?>
                    ['May',<?php echo e($chart->sales); ?>],
                    <?php break; ?>
            <?php endswitch; ?>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
            ]);

            var options = {
            title: 'Sales Chart of the Year',
            titleTextStyle: {
                color: 'white',
            },
            
            pieHole: 0,
                pieSliceTextStyle: {
                    color: 'black',
                },
                is3D: true,
                backgroundColor: '#03528e',
                legend: 'none'
            };
            var chart = new google.visualization.PieChart(document.getElementById("piechart"));
            chart.draw(data,options);
            }
            
    </script>
    <style>
        body{
            font-family: cursive;
            background-color:rgba(6, 6, 6, 0.797);
        }

        
    </style>

</head>
<body>
        <div id="sidebar">
            <ul>
                <li id="site-name"><p>BLOUNGE</p></li>
                <li style="margin-left:-5px;"><div class="row"><img src="images/adminavatar.png" id="pro-pic" style="margin-left:10px">&nbsp&nbsp<a><p style="margin-top:20px"><?php echo e($user->fullname); ?></p></a></div></li>
                <li  id="db"><a href="/adminDashboard">DASHBOARD</a></li>
                <li  id="book"><a href="/adbook">BOOK</a></li>
                <li  id="member"><a href="/admembers">MEMBERS</a></li>
                <li  id="order"><a href="/adorders">ORDERS</a></li>
                <li id="Logout"><a href="/logout">LOG OUT</a></li>
            </ul>
        </div>
        <div id="dashboard"><br>
            <br><br><h2>DASHBOARD</h2><br>
            <div class="container-fluid">
            <div id="piechart" style="width: 100%; height: 250px;"></div>
            </div><br>
                    <div id="box1" class="dash-box">
                        <img src="images/images.png" height="30px" width="30px"><br><br>
                        <table id="view-book-tab">
                    <thead>
                    <tr>
                        <th colspan="7">ORDERS</th>
                    </tr>
                    <tr>
                        <th>SL.NO</th>
                        <th>ORDERID</th>
                        <th>CUSTOMER</th>
                        <th>ADDRESS</th>
                        <th>PLACED TIME</th>
                        <th>AMOUNT</th>
                        <th>STATUS</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($o->orderid); ?></td>
                            <td><?php echo e($o->cust->fullname); ?></td>
                            <td><address><?php echo e($o->ship->address); ?><br><?php echo e($o->ship->city); ?> <?php echo e($o->ship->zipcode); ?><br><?php echo e($o->ship->state); ?> <?php echo e($o->ship->country); ?></address></td>
                            <td><?php echo e($o->placed_at); ?></td>
                            <td><?php echo e($o->paymentamt); ?></td>
                            <?php if($o->status==1): ?>
                            <td style="color:orange">Pending</td>
                            <?php else: ?>
                            <td style="color:cyan">Processing</td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                </div><br>
                    <div class="dash-box">
                        <img src="images/block.png" height="30px" width="30px">
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos laboriosam ipsa illum, in impedit sapiente ab ullam</p><br>
                    </div> <br>
                    <!-- <div class="dash-box">
                        <img src="images/stock.png" height="30px" width="30px">
                        <p>Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eos laboriosam ipsa illum, in impedit sapiente ab ullam</p><br>
                    </div> <br> -->              

            <br>
                      
        </div>

</body><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/AdDashboard.blade.php ENDPATH**/ ?>