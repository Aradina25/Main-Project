<head>
    <title>adminDasboard</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('addash.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
    </script>
    <style>
        body{
            font-family: cursive;
            background-color:rgba(6, 6, 6, 0.797);
        }
    </style>

</head>
<body>
        <div id="sidebar">
            <ul>
                <li id="site-name"><p>BLOUNGE</p></li>
                <li style="margin-left:-5px;"><div class="row"><img src="images/adminavatar.png" id="pro-pic" style="margin-left:10px">&nbsp&nbsp<a><p style="margin-top:20px"><?php echo e($user->fullname); ?></p></a></div></li>
                <li  id="db"><a href="/adminDashboard">DASHBOARD</a></li>
                <li  id="book"><a href="/adbook">BOOK</a></li>
                <li  id="member"><a href="#">MEMBERS</a></li>
                <li  id="order"><a>ORDERS</a></li>
                <li id="Logout"><a href="/logout">LOG OUT</a></li>
            </ul>
    </div>
        <div id="dashboard" style="margin-top:50px;"><br>
            <h2>MEMBER MANAGEMENT</h2>
            <table id="view-book-tab">
                    <thead>
                    <tr>
                        <th>SL.NO</th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('fullname','NAME'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('dob','DOB'));?></th>
                        <th><?php echo \Kyslik\ColumnSortable\SortableLink::render(array ('age','AGE'));?></th>
                        <th>ACTION</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $mem1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td></td>
                            <td><?php echo e($member->fullname); ?></td>
                            <td><?php echo e($member->dob); ?></td>
                            <td><?php echo e($member->age); ?></td>
                            <form action="<?php echo e(route('admempro',$member->userid)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <td><button type="submit">VIEW</button></td>
                            </form>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
        </div>

</body><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/adminMembers.blade.php ENDPATH**/ ?>