

<?php $__env->startSection('title','HOME'); ?>
<?php $__env->startSection('username',$user->fullname); ?>
<?php $__env->startSection('width',$width); ?>
<?php $__env->startSection('comptgoal',$challenge->completedgoal); ?>
<?php $__env->startSection('goal',$challenge->goal); ?>
<?php $__env->startSection('picture',$profile->picture); ?>

<style>
     
    article{
        border-left:3px solid #a21b24;
    }
    .info{
        color: #aaa;
        font-style: italic;
    }
    

    #whats-on-mind{
        margin-top:10px;
        margin-left:10px;
        width:470px;
        height:120px;
        border:none;
    }

    #whats-on-mind{
        overflow: auto;
        outline: none;

        -webkit-box-shadow: none;
        -moz-box-shadow: none;
        box-shadow: none;

        resize: none;
    }
    #upload-icon{
        border:1px solid black;
    }

    #file-input{
        display:none;
    }
    #upload{
        margin-top:20px;
    }
    #upload-btn{
        margin-top:20px;
    }
    /* #addyourstoremodal{
        
    max-width: 80%;
    } */
</style>

<?php $__env->startSection('content'); ?>
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Reading Challenge</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Your Progress</h6>
                    <div class="progress" style="width:455px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $__env->yieldContent('width'); ?>%" aria-valuenow="<?php echo $__env->yieldContent('comptgoal'); ?>" aria-valuemin="0" aria-valuemax="<?php echo $__env->yieldContent('goal'); ?>"><?php echo $__env->yieldContent('comptgoal'); ?>/<?php echo $__env->yieldContent('goal'); ?></div>
                    </div><br>
                    <?php if($challenge->goal==0): ?>
                        <h6>Start your challenge</h6>
                        <form action="/challenge" method="POST">
                            <?php echo csrf_field(); ?>
                                <label for="goalsetter">Set the number of books you will read within 3 months</label>
                                <?php if(Session::has('ming')): ?>
                                <div class="alert alert-danger" role="alert"><?php echo e(Session::get('ming')); ?></div>
                                <?php endif; ?>
                                <input type="number" id="goalsetter" name="goalsetter" oninput="this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null">
                                <button type="submit" class="btn btn-primary">Set</button>
                            </form>
                        <?php else: ?>
                        <div class="book-list">
                            <h6>Completed Books</h6>
                            <tr>
                            <?php $__currentLoopData = $librarycheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><a href="<?php echo e(route('memviewbook',$book->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$book->products->cov_pic)); ?>" alt="<?php echo e($book->products->title); ?>" style="width:50px;height:60px;"></a></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </div>
                    <?php endif; ?>
                        
                            
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.location='<?php echo e(url('/memsearch')); ?>'">Add completed books</button>
                </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="MemberLibrary" tabindex="-1" role="dialog" aria-labelledby="MemberLibraryTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="MemberLibraryTitle">Your Shelf</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="book-list">
                        <h6>To Be Read</h6>
                        <tr>
                        <?php $__currentLoopData = $tbr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$t->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$t->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6>Currently Reading</h6>
                        <tr>
                        <?php $__currentLoopData = $curr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$c->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$c->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6>Completed</h6>
                        <tr>
                        <?php $__currentLoopData = $done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$d->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$d->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <h6>EBooks</h6>
                        <td><a href="https://online.fliphtml5.com/lunzf/oxuu/"><img src="<?php echo e(asset('coverpics/1663776805cp.jpg')); ?>" style="width:50px;height:60px;"></a></td>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.location='<?php echo e(url('/memsearch')); ?>'">Add More to Library</button>
                </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="yourstoremodal" tabindex="-1" role="dialog" aria-labelledby="yourstoremodalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="yourstoremodalTitle">Your store</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="book-list">
                        <h6> Currently on store </h6>
                        <tr>
                        <?php $__currentLoopData = $tobesold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href=""><img src="<?php echo e(asset('coverpics/'.$t->frontcov)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6> Sold  </h6>
                        <tr>
                        <?php $__currentLoopData = $soldbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href=""><img src="<?php echo e(asset('coverpics/'.$s->frontcov)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6><a href="/currsale">Click to view current sales</a></h6>
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addyourstoremodal" >Add to your store</button>
                </div>
                </div>
            </div>
        </div>
        
        <div id="mid-view" class="child-element" style="width:700px;margin-left:20%;margin-top:20px;">
        <div style="border-bottom:3px solid #98AE42;background:white;height:170px;">  
            <div style="float:left;vertical-align:top;border-radius:50%;margin-top:10px;">
                <image id="profileImage" src="<?php echo e(asset('profilepictures/'.$profile->picture)); ?>" style="width:150px;height:150px;border-radius: 50%;"><br>
            </div>
            <?php if(count($follow)>0): ?>
                                <?php $__currentLoopData = $follow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($follow->friendid == $user->userid): ?>
                                        <?php ($button = "Unfollow"); ?>
                                    <?php else: ?>
                                        <?php ($button = "Follow"); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
                    <?php ($button = "Follow"); ?>
            <?php endif; ?>
            <div style="margin-left:5%;margin-top:10px;">
                <h2><?php echo e($frnd->fullname); ?></h2>
                <h5><?php echo e($profile->bio); ?></h5>
                <p style="float:left;"><b>Level : <?php echo e($profile->level); ?></b></p>
                <p style="margin-left:200px;"><b>Reward coins available : <?php echo e($profile->coins); ?></b></p>
                <form action="<?php echo e(route('follow',$user->userid)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-outline-success" name="follow" id="follow"><?php echo e($button); ?></button>
                </form>
                </div>      
        </div>  
            <?php if(count($posts)>0): ?>

            <h3 style="margin-top:5%;">Posts</h3><br>
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php ($postid = $posts->postid); ?>
            <article class="post">
                <div class="card mb-3" style="max-width: 700px;">
                    <div class="row g-0">
                        <div class="col-md-4">
                            <image id="posts" src="<?php echo e(asset('posts/'.$posts->image)); ?>" style="width:150px;height:100%;"><br>
                        </div>
                        <div class="col-md-8">
                            <div class="card-body">
                            <!-- <li class="icons dropdown"> -->
                            <div class="user-img c-pointer position-relative"   data-toggle="dropdown" style="margin-left:400px;">
                                <span class="activity active"></span>
                                <img src="<?php echo e(asset('images/threedots.jpg')); ?>" height="20" width="40" alt="options">
                            </div>
                            <div class="drop-down dropdown-profile animated fadeIn dropdown-menu">
                                <div class="dropdown-content-body">
                                    <ul>
                                        <?php if($posts->status == 1): ?>
                                        <li><a data-id="<?php echo e($postid); ?>" data-toggle="modal" data-target="#editposts" class="editposts" style="color:black;cursor:pointer" >Edit</a></li>
                                        <?php endif; ?>
                                        <li><a href="<?php echo e(route('deletepost',$postid)); ?>" style="color:black;cursor:pointer">Delete</a></li>
                                    </ul>
                                </div>
                            </div>
                                <br>
                                <p class="card-text"><?php echo e($posts->body); ?></p>
                                <p class="card-text"><small class="text-muted">You posted this on <?php echo e($posts->created_at); ?></small></p>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        <?php endif; ?>  
        </div>
        <div class="modal fade" id="editposts" tabindex="-1" role="dialog" aria-labelledby="editpostsTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editpostsTitle">EDIT POST</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                    
                </div>
                <div class="modal-body">
                <form action="/editposts" method="POST" enctype="multipart/form-data"> 
                <?php echo csrf_field(); ?>
                    <textarea id="whats-on-mind" name="editwom" placeholder="Whats on your mind...." ></textarea><br>
                    <label for="file-input">
                    <span id="errcp"></span><br><img src="images/post.png" name="upload-icon" id="upload" style="width:50px; height:50px;" >
                    <input type="file" id="file-input" name="editimage" onchange="fileValidation()">
                    </label>
                    <!-- <input type="text" id="id" name="id" value="{{}}"> -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">UPLOAD</button>
                    </form>  
                </div>
                </div>
            </div>
        </div> 

        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.usertemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/friendprofile.blade.php ENDPATH**/ ?>