<head>
    <title><?php echo e($viewbook->title); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('addash.css')); ?>">
    <script src="<?php echo e(asset('validation.js')); ?>"></script>
    <script src="<?php echo e(asset('jquery-3.6.0.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function(){
                $('#edit-book').hide();
                // $('#searchbox').hide();
                $('#edit-btn').click(function(){
                    $('#edit-btn').hide();
                    //$('#update-book-btn').show();
                    $('#edit-book').show();
                    $('#view-spec-book').hide();
                });
                $('#back-btn').click(function(){
                    $('#view-spec-book').show();
                    $('#edit-book').hide();
                    $('#edit-btn').show();
                });
            });
    </script>
</head>
<body>
    <div id="sidebar">
        <ul>
                <li id="site-name"><p>BLOUNGE</p></li>
                <li><div class="row"><img src="<?php echo e(asset('images/adminavatar.png')); ?>" id="pro-pic" style="margin-left:10px">&nbsp&nbsp<a><p style="margin-top:20px"><?php echo e($user->fullname); ?></p></a></div></li>
                <li  id="db"><a href="/adminDashboard">DASHBOARD</a></li>
                <li  id="book"><a href="/adbook">BOOK</a></li>
                <li  id="member"><a>MEMBERS</a></li>
                <li  id="order"><a>ORDERS</a></li>
                <li id="Logout" style="margin-top:80px"><a href="/logout">LOG OUT</a></li>
            </ul>
    </div>
    <br><br><br>
    <div id="dashboard">
        <div id="view-spec-book">
            <div class="row">
                <h2><?php echo e($viewbook->title); ?> - <?php echo e($viewbook->author); ?></h2>
                <button id="edit-btn" style="margin-left: 50px;margin-top:20px;">EDIT</button>
                <button id="back-btn-i" style="margin-left: 10px;margin-top:20px;" onclick="location.href='/adbook'">BACK</button>
            </div>
            <table id="spec-book-tab">
                <tr>
                    <td rowspan="4"><img src="<?php echo e(asset('coverpics/'.$viewbook->cov_pic)); ?>" id="cov-pic"></td>
                    <td>Genre : <?php echo e($viewbook->genre); ?> </td>
                    <td>ISBN : <?php echo e($viewbook->ISBN); ?> </td>
                    <td>No.of pages : <?php echo e($viewbook->pages); ?> </td>
                </tr>
                <tr>
                    <td>Publisher : <?php echo e($viewbook->publisher); ?> </td>
                    <td>Language : <?php echo e($viewbook->language); ?> </td>
                    <td>Publish Date : <?php echo e($viewbook->publish_date); ?> </td>
                </tr>
                <?php $__currentLoopData = $stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($stock->type); ?></td>
                        <td>Price <?php echo e($stock->price); ?></td>
                        <td>Discount <?php echo e($stock->discount); ?>%</td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                     <td colspan="4" id="spec-summary"><?php echo e($viewbook->summary); ?></td>
                </tr>
            </table>
        </div>
        <div id="edit-book">
            <div class="row">
                <h3>EDIT BOOK</h3><br>
                <button id="back-btn" style="margin-left: 680px;">BACK</button>
            </div>
            <form action="<?php echo e(route('editbook',$viewbook->accession_no)); ?>" method="POST" enctype="multipart/form-data">
                <?php if(Session('status')): ?>
                    <span style="color:red"><?php echo e(Session('status')); ?></span>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <table id="add-book-tab">
                    <tr>
                        <td><label for="cp">Cover Picture <Picture></Picture></label></td>
                        <td><span id="errcp"></span><br><input type="file" id="cp" name="cov_pic" class="input-box" value="<?php echo e(asset('coverpics/'.$viewbook->cov_pic)); ?>" onchange="fileValidation()" required></td>
                    </tr>
                    <tr>
                        <td><label for="title">Title</label></td>
                        <td><span id="titleerr"></span><input type="text" id="title" name="title" class="input-box" value="<?php echo e($viewbook->title); ?>" onkeyup="ValidateTitle()" required></td>
                    </tr>
                    <tr>
                        <td><label for="author">Author</label></td>
                        <td><span id="autherr"></span><input type="text" id="author" name="author" class="input-box" value="<?php echo e($viewbook->author); ?>" onkeyup="ValidateAuthor()" required></td>
                    </tr>
                    <tr>
                        <td><label for="genre">Genre</label></td>
                        <td><span id="generr"></span><input type="text" id="genre" name="genre" class="input-box" value="<?php echo e($viewbook->genre); ?>" onkeyup="ValidateGenre()" required></td>
                    </tr>
                    <tr>
                        <td><label for="summary">Summary</label></td>
                        <td><textarea id="summary" name="summary" rows="10" cols="108" required><?php echo e($viewbook->summary); ?></textarea></td>
                    </tr>
                    <tr>
                        <td><label for="pages">Pages</label></td>
                        <td><input type="number" id="pages" name="pages" class="input-box" value="<?php echo e($viewbook->pages); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="lang">Language</label></td>
                        <td><span id="errlang"></span><input type="text" id="lang" name="language" class="input-box" value="<?php echo e($viewbook->language); ?>" onkeyup="ValidateLang()" required></td>
                    </tr>
                    <tr>
                        <td><label for="publisher">Publisher</label></td>
                        <td><span id="puberr"></span><input type="text" id="publisher" name="publisher" class="input-box" value="<?php echo e($viewbook->publisher); ?>" onkeyup="ValidatePub()" required></td>
                    </tr>
                    <tr>
                        <td><label for="publish-date">Publish Date</label></td>
                        <td><input type="date" id="publish-date" name="publish_date" class="input-box" value="<?php echo e($viewbook->publish_date); ?>" required></td>
                    </tr>
                    <tr>
                        <td><label for="ISBN">ISBN</label></td>
                        <td><span id="isbnerr"></span><input type="number" id="ISBN" name="ISBN" class="input-box" value="<?php echo e($viewbook->ISBN); ?>" onkeyup="ValidateISBN()" required></td>
                    </tr>
                    <tr> 
                        <td><label for="addbook">Action</label></td>
                        <td><input type="submit" id="addbook" name="editbook" value="EDIT" class="input-box"></td>
                    </tr>

                </table>                
            </form>
        </div>
    </div>
</body><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/ViewSpecBook.blade.php ENDPATH**/ ?>