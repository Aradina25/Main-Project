

<?php $__env->startSection('title','Search results for '.$s); ?>
<?php $__env->startSection('username',$user->fullname); ?>
<?php $__env->startSection('width',$width); ?>
<?php $__env->startSection('comptgoal',$challenge->completedgoal); ?>
<?php $__env->startSection('goal',$challenge->goal); ?>
<?php $__env->startSection('tbr',count($tbr)); ?>
<?php $__env->startSection('curr',count($curr)); ?>
<?php $__env->startSection('done',count($done)); ?>
<head>
   <style>

        #mini-cov-pic{
            width:50px;
            height:70px;
        }

        #dashboard #view-book-tab{
            border-collapse: collapse;
            /* width:600px; */
        }

        #dashboard #view-book-tab td{
            padding: 10px;
        }

        #spec-book-tab td{
            padding:50px;
        }

   </style>
</head>
<?php $__env->startSection('content'); ?>
<div id="dashboard">
        <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalCenterTitle">Reading Challenge</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <h6>Your Progress</h6>
                    <div class="progress" style="width:455px;">
                        <div class="progress-bar bg-success" role="progressbar" style="width: <?php echo $__env->yieldContent('width'); ?>%" aria-valuenow="<?php echo $__env->yieldContent('comptgoal'); ?>" aria-valuemin="0" aria-valuemax="<?php echo $__env->yieldContent('goal'); ?>"><?php echo $__env->yieldContent('comptgoal'); ?>/<?php echo $__env->yieldContent('goal'); ?></div>
                    </div><br>
                    <?php if($challenge->goal==0): ?>
                        <h6>Start your challenge</h6>
                        <form action="/challenge" method="POST">
                            <?php echo csrf_field(); ?>
                                <label for="goalsetter">Set the number of books you will read within 3 months</label>
                                <?php if(Session::has('ming')): ?>
                                <div class="alert alert-danger" role="alert"><?php echo e(Session::get('ming')); ?></div>
                                <?php endif; ?>
                                <input type="number" id="goalsetter" name="goalsetter" oninput="this.value = !!this.value && Math.abs(this.value) >= 0 ? Math.abs(this.value) : null">
                                <button type="submit" class="btn btn-primary">Set</button>
                            </form>
                        <?php else: ?>
                        <div class="book-list">
                            <h6>Completed Books</h6>
                            <tr>
                            <?php $__currentLoopData = $librarycheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><a href="<?php echo e(route('memviewbook',$book->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$book->products->cov_pic)); ?>" alt="<?php echo e($book->products->title); ?>" style="width:50px;height:60px;"></a></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </div>
                    <?php endif; ?>
                        
                            
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.location='<?php echo e(url('/memsearch')); ?>'">Add completed books</button>
                </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="MemberLibrary" tabindex="-1" role="dialog" aria-labelledby="MemberLibraryTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="MemberLibraryTitle">Your Shelf</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                <div class="book-list">
                        <h6>To Be Read</h6>
                        <tr>
                        <?php $__currentLoopData = $tbr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$t->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$t->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6>Currently Reading</h6>
                        <tr>
                        <?php $__currentLoopData = $curr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$c->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$c->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6>Completed</h6>
                        <tr>
                        <?php $__currentLoopData = $done; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href="<?php echo e(route('memviewbook',$d->products->accession_no)); ?>"><img src="<?php echo e(asset('coverpics/'.$d->products->cov_pic)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <h6>EBooks</h6>
                        <td><a href="https://online.fliphtml5.com/lunzf/oxuu/"><img src="<?php echo e(asset('coverpics/1663776805cp.jpg')); ?>" style="width:50px;height:60px;"></a></td>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" onclick="window.location='<?php echo e(url('/memsearch')); ?>'">Add More to Library</button>
                </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="yourstoremodal" tabindex="-1" role="dialog" aria-labelledby="yourstoremodalTitle" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="yourstoremodalTitle">Your store</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <div class="book-list">
                        <h6>Currently on store</h6>
                        <tr>
                        <?php $__currentLoopData = $tobesold; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href=""><img src="<?php echo e(asset('coverpics/'.$t->frontcov)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        <h6>Sold</h6>
                        <tr>
                        <?php $__currentLoopData = $soldbooks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><a href=""><img src="<?php echo e(asset('coverpics/'.$s->frontcov)); ?>" alt="" style="width:50px;height:60px;"></a></td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                        <br>
                        <br>
                        
                    </div>
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addyourstoremodal" >Add to your store</button>
                </div>
                </div>
            </div>
        </div>
    <div id="mid-view" class="child-element">
        <table id="view-book-tab">
            <tbody>
                <?php if(count($search)>0): ?>
                    <?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td rowspan="2"><img src="<?php echo e(asset('coverpics/'.$book->cov_pic)); ?>" id="mini-cov-pic"></td>
                        <td colspan="3"><b><?php echo e($book->title); ?> - <?php echo e($book->author); ?></b></td>
                    </tr>
                    <tr>
                        <td><?php echo e($book->genre); ?> -
                        </td>
                        <form action="<?php echo e(route('memviewbook',$book->accession_no)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <td><button type="submit" class="btn btn-primary">MORE</button></td>
                        </form>
                        <td><div class="btn-group">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:150px;">
                        Save to Library
                    </button>
                    <div class="dropdown-menu">
                        <a class="dropdown-item" href="<?php echo e(route('markbook',['accId'=>$book->accession_no,'stat'=>1])); ?>">Want to Read</a>
                        <a class="dropdown-item" href="<?php echo e(route('markbook',['accId'=>$book->accession_no,'stat'=>2])); ?>">Currently Reading</a>
                        <a class="dropdown-item" href="<?php echo e(route('markbook',['accId'=>$book->accession_no,'stat'=>3])); ?>">Read</a>
                    </div>
                </div>
            </div></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                <?php if(count($searchp)>0): ?>
                    <?php $__currentLoopData = $searchp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(count($follow)>0): ?>
                                <?php $__currentLoopData = $follow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $follow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($follow->friendid == $user->userid): ?>
                                        <?php ($button = "Unfollow"); ?>
                                    <?php else: ?>
                                        <?php ($button = "Follow"); ?>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php ($button = "Follow"); ?>
                            <?php endif; ?>
                            <tr>
                                <td rowspan="2"><img src="<?php echo e(asset('profilepictures/'.$user->pics->picture)); ?>" style="border-radius:50%;width:100px;height:100px;"></td>
                                <td colspan="3"><b><?php echo e($user->fullname); ?> - Level <?php echo e($user->pics->level); ?> </b></td>
                            </tr>
                        <tr>
                            <td><?php echo e($user->pics->bio); ?></td>
                            <td>
                            <form action="<?php echo e(route('follow',$user->userid)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-outline-success" name="follow" id="follow"><?php echo e($button); ?></button>
                            
                            <button type="submit" class="btn btn-primary" formaction="<?php echo e(route('friendprofile',$user->userid)); ?>">VIEW</button>
                            </form>    
                        </td>
                            </div>
                        </tr>
                        
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                
            </tbody>
        </table>
    </div>
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.usertemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/userviewbook.blade.php ENDPATH**/ ?>