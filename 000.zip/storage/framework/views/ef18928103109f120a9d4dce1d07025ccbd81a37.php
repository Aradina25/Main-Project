<head>
    <title><?php echo e($viewbook->title); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <script src="<?php echo e(asset('https://code.jquery.com/jquery-3.2.1.slim.min.js')); ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js')); ?>" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js')); ?>" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js')); ?>" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('validation.js')); ?>"></script>
    
    
  <!-- Google Fonts -->
  <link href="<?php echo e(asset('https://fonts.gstatic.com')); ?>" rel="preconnect">
  <link href="<?php echo e(asset('https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i')); ?>" rel="stylesheet">
  <link rel="stylesheet"href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  

  <!-- Vendor CSS Files -->
    <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/bootstrap-icons/bootstrap-icons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/boxicons/css/boxicons.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/quill/quill.snow.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/quill/quill.bubble.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/remixicon/remixicon.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('vendor/simple-datatables/style.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('jquery-3.6.0.min.js')); ?>"></script>
    <link rel="stylesheet" type="text/css" href="index.css">
    
   <style>
        #fixed-view{
            position:fixed;
            height:100%;
            width:160px;
        }

        .card{
            width:135px;
        }

        td{
            padding:5px;
        }

        sup{
            color: red;
        }
        .rate {
            float: left;
            height: 30px;
            padding: 0 10px;
        }
        .rate:not(:checked) > input {
            position:absolute;
            top:-9999px;
        }
        .rate:not(:checked) > label {
            float:right;
            width:1em;
            overflow:hidden;
            white-space:nowrap;
            cursor:pointer;
            font-size:20px;
            color:#ccc;
        }
        .rate:not(:checked) > label:before {
            content: '★ ';
        }
        .rate > input:checked ~ label {
            color: #ffc700;    
        }
        .rate:not(:checked) > label:hover,
        .rate:not(:checked) > label:hover ~ label {
            color: #deb217;  
        }
        .rate > input:checked + label:hover,
        .rate > input:checked + label:hover ~ label,
        .rate > input:checked ~ label:hover,
        .rate > input:checked ~ label:hover ~ label,
        .rate > label:hover ~ input:checked ~ label {
            color: #c59b08;
        }
        .checked {
          color: #ffc700;
        }

   </style>
</head>
<header class="head">       
            <p>BLOUNGE</p>
            <div class="header_nav">
                <nav>
                    <a href="/">HOME &nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <a href="/reg">SIGN UP &nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <a href="/login">SIGN IN</a>
                </nav>
            </div>
        </header>
<div id="dashboard">
<div id="view-spec-book">
            
    <div id="mid-view" class="child-element" style="background:white;">
            <div id="fixed-view" style="margin-left:40px;margin-top:50px;">
                <img src="<?php echo e(asset('coverpics/'.$viewbook->cov_pic)); ?>" id="cov-pic" width=150px; height=200px;><br><br>
                <div class="btn-group">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:200px;">
                        Save to Library
                    </button>
                    <div class="dropdown-menu">
                    <a class="dropdown-item" href="/login">Want to Read</a>
                        <a class="dropdown-item" href="/login">Currently Reading</a>
                        <a class="dropdown-item" href="/login">Read</a>
                    </div>
                </div>
                <table style="width:220px;">
                    <tr>
                        <td>HardCover</td>
                        <?php if(empty($pricehc)!=1): ?>
                            <?php if($pricehc->discount == 0): ?>
                                <td>₹<?php echo e($pricehc->price); ?></td>
                            <?php else: ?>
                            <td><s>₹<?php echo e($pricehc->price); ?></s> ₹<?php echo e(($pricehc->price)-(($pricehc->discount*$pricehc->price)/100)); ?><sup> <?php echo e($pricehc->discount); ?>% off</sup> </td>                          
                            <?php endif; ?>
                        <?php else: ?>
                            <td>Out of stock</td>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <td>Paperback</td>
                        <?php if(empty($pricepb)!=1): ?>
                            <?php if($pricepb->discount == 0): ?>
                                <td>₹<?php echo e($pricepb->price); ?></td>
                            <?php else: ?>
                            <td><s>₹<?php echo e($pricepb->price); ?></s>  ₹<?php echo e(($pricepb->price)-(($pricepb->discount*$pricepb->price)/100)); ?><sup> <?php echo e($pricepb->discount); ?>% off</sup></td>
                            <?php endif; ?>
                        <?php else: ?>
                            <td>Out of stock</td>
                        <?php endif; ?>                        
                    </tr>
                    <tr>
                        <td>EBook</td>
                        <?php if(empty($priceeb)!=1): ?>
                            <?php if($priceeb->discount == 0): ?>
                                <td>₹<?php echo e($priceeb->price); ?></td>
                            <?php else: ?>
                            <td><s>₹<?php echo e($priceeb->price); ?></s> ₹<?php echo e(($priceeb->price)-(($priceeb->discount*$priceeb->price)/100)); ?><sup> <?php echo e($priceeb->discount); ?>% off</sup></td>
                            <?php endif; ?>
                        <?php else: ?>
                            <td>Not Available</td>
                        <?php endif; ?>
                    </tr>
                </table>
                <div class="btn-group">
                    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="width:200px;">
                        Add To Cart
                    </button>
                    <div class="dropdown-menu">
                        <?php if(empty($pricehc)!=1): ?>
                            <a class="dropdown-item" href="/login">Hardcover</a>
                        <?php endif; ?>
                        <?php if(empty($pricepb)!=1): ?>
                            <a class="dropdown-item" href="/login">Paperback</a>
                        <?php endif; ?>
                        <?php if(empty($priceeb)!=1): ?>
                            <a class="dropdown-item" href="/login">E-Book</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div id="rest-view" style="margin-left:350px;width:800px;margin-top:50px;"><br>
                <h2><?php echo e($viewbook->title); ?> - <?php echo e($viewbook->author); ?></h2>
                <?php ($rate = $viewbook->rating); ?>
                <?php for($i = 0; $i < $rate; $i++): ?>
                <span class="fa fa-star checked" style="font-size:20px;"></span>
                <?php endfor; ?>
                <?php ($rate = 5-$viewbook->rating); ?>
                <?php for($i = 0; $i < $rate; $i++): ?>
                <span class="fa fa-star" style="font-size:20px;"></span>
                <?php endfor; ?>
                <br><br>

                <p style="text-align: justify"><?php echo e($viewbook->summary); ?></p>
                <div class="accordion accordion-flush" id="accordionFlushExample">
                    <div class="accordion-item">
                        <h2 class="accordion-header" id="flush-headingOne">
                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                                Book Details
                            </button>
                        </h2>
                        <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
                            <div class="accordion-body">
                                <table id="spec-book-tab">
                                    <tr>
                                        <td>Genre</td>
                                        <td><?php echo e($viewbook->genre); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Language</td>
                                        <td><?php echo e($viewbook->language); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>No.of pages</td>
                                        <td><?php echo e($viewbook->pages); ?></td>
                                    </tr>
                                    <tr>
                                        <td>ISBN</td> 
                                        <td><?php echo e($viewbook->ISBN); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Publisher</td>
                                        <td> <?php echo e($viewbook->publisher); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Publish Date</td>
                                        <td><?php echo e($viewbook->publish_date); ?> </td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <p><b>Rate and Review the book</b></p>
                <p style="float:left;margin-top:5px;">Rate :</p>
                    <div class="rate">
                      <input type="radio" id="star5" name="rating" value="5" />
                      <label for="star5" title="text">5 stars</label>
                      <input type="radio" id="star4" name="rating" value="4" />
                      <label for="star4" title="text">4 stars</label>
                      <input type="radio" id="star3" name="rating" value="3" />
                      <label for="star3" title="text">3 stars</label>
                      <input type="radio" id="star2" name="rating" value="2" />
                      <label for="star2" title="text">2 stars</label>
                      <input type="radio" id="star1" name="rating" value="1" />
                      <label for="star1" title="text">1 star</label>
                    </div><br><br>
                    <textarea id="review" rows="5" cols="82" name="review" placeholder=" Enter your review"></textarea><br><br>
                    <button class="btn btn-success" style="width:700px;" onclick="location.href='/login'">Enter</button>
                <br><br>
            <?php $__currentLoopData = $reviewtab; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $posts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="post">
                <div class="card mb-3" style="width: 700px;">
                    <div class="row g-0">
                        <div class="col-md-4" style="width:80px;padding-top:10px;">
                            <image id="posts" src="<?php echo e(asset('profilepictures/'.$posts->pic->picture)); ?>" style="width:70px;height:70px;border-radius:50px;"><br>
                        </div>
                        <div class="col-md-8">
                            <div class="card-body" style="text-align:left;padding-bottom:10px;">
                            <!-- <li class="icons dropdown"> -->
                                <br>
                                <p class="card-text"><small class="text-muted"><?php echo e($posts->details->fullname); ?></small></p>
                                <?php ($rate = $posts->rating); ?>
                                <?php for($i = 0; $i < $rate; $i++): ?>
                                <span class="fa fa-star checked" style="font-size:15px;"></span>
                                <?php endfor; ?>
                                <?php ($rate = 5-$posts->rating); ?>
                                <?php for($i = 0; $i < $rate; $i++): ?>
                                <span class="fa fa-star" style="font-size:15px;"></span>
                                <?php endfor; ?>
                                <p class="card-text"><?php echo e($posts->review); ?></p>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                <br><br>
            </div>   
            
            
        </div> 
    </div>
</div>

<?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/scanbook.blade.php ENDPATH**/ ?>