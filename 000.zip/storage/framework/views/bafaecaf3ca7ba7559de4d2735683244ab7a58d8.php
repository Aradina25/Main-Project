<head>
    <title>Login</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link href="<?php echo e(asset('https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css')); ?>" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous">

    <link rel="stylesheet" type="text/css" href="login.css">

    <script type="text/javascript">
function callbackThen(response) {
    // read Promise object
    response.json().then(function(data) {
        console.log(data);
        if(data.success && data.score > 0.5) {
            console.log('valid recpatcha');
        } else {
            document.getElementById('registerForm').addEventListener('submit', function(event) {
                event.preventDefault();
                alert('recpatcha error');
            });
        }
    });
}
 
function callbackCatch(error){
    console.error('Error:', error)
}
</script>
     
<?php echo htmlScriptTagJsApi([
    'callback_then' => 'callbackThen',
    'callback_catch' => 'callbackCatch',
]); ?>

</head>
    <body>
    <header class="head">       
            <p>BLOUNGE</p>
            <div class="header_nav">
                <nav>
                    <a href="/">HOME &nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <a href="/reg">SIGN UP &nbsp;&nbsp;&nbsp;&nbsp;</a>
                    <a href="/login">SIGN IN</a>
                </nav>
            </div>
        </header>
        <div class="form-box">
            <h2>SIGN IN TO YOUR ACCOUNT</h2>
            <form action="/loguser" method="POST">
                <?php if(Session::has('fail')): ?>
                <div class="alert alert-danger" role="alert" style="margin-left: 150px;width: 500px;"><?php echo e(Session::get('fail')); ?></div>
                <?php endif; ?>
                <?php echo csrf_field(); ?>
                <?php $__errorArgs = ['uname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="email" id="uname" name="uname" class="logindetails" placeholder="email"><br><br>
                <?php $__errorArgs = ['pass'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <input type="password" id="pass" name="pass" class="logindetails" placeholder="password"><br><br>
                <a style="margin-left: 155px; color:black" href="/forgotpass">Forgot password?</a>
                <br><br>
                <input style="margin-left: 370px;" type="submit" value="SIGN IN" class="btn" name="signin"><br><br>
                <p style="margin-left: 155px;"><b>New to BLounge? <a href="/reg">SIGN UP HERE</b></p>

            </form>
        </div>
    </body>
</html><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/login.blade.php ENDPATH**/ ?>