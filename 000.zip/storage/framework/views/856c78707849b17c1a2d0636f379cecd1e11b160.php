
<head>
    <title>MEMBER MANAGEMENT</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('addash.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="jquery-3.6.0.min.js"></script>
    <script type="text/javascript">
    </script>
    <style>
        body{
            font-family: cursive;
            background-color:rgba(6, 6, 6, 0.797);
        }
        .alert {
            padding: 20px;
            background-color: orange;
            color: black;
        }

        .closebtn {
            margin-left: 15px;
            color: white;
            font-weight: bold;
            float: right;
            font-size: 22px;
            line-height: 20px;
            cursor: pointer;
            transition: 0.3s;
        }

        .closebtn:hover {
            color: black;
        }
    </style>

</head>
<body>
        <div id="sidebar">
            <ul>
                <li id="site-name"><p>BLOUNGE</p></li>
                <li style="margin-left:-5px;"><div class="row"><img src="<?php echo e(asset('images/adminavatar.png')); ?>" id="pro-pic" style="margin-left:10px">&nbsp&nbsp<a><p style="margin-top:20px"><?php echo e($user->fullname); ?></p></a></div></li>
                <li  id="db"><a href="/adminDashboard">DASHBOARD</a></li>
                <li  id="book"><a href="/adbook">BOOK</a></li>
                <li  id="member"><a href="#">MEMBERS</a></li>
                <li  id="order"><a>ORDERS</a></li>
                <li id="Logout"><a href="/logout">LOG OUT</a></li>
            </ul>
    </div>
    <div id="dashboard" style="margin-top:10px;"><br>
    <div class="row">
    <h2>MEMBER MANAGEMENT</h2>
    <form action="<?php echo e(route('blck',['id'=>$Id,'role'=>3])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($memreg->status ==3): ?>
        <button type="submit" style="background-color:darkorange;margin-left:300px;margin-top:20px;">UNSUSPEND</button>
        <?php else: ?>
        <button type="submit" style="background-color:darkorange;margin-left:300px;margin-top:20px;">SUSPEND</button>
    <?php endif; ?>
    </form>
    
    <form action="<?php echo e(route('blck',['id'=>$Id,'role'=>0])); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php if($memreg->status==2): ?>
        <button type="submit" style="background-color:red;margin-left:10px;margin-top:20px;">BLOCK</button>
    <?php else: ?>
        <button type="submit" style="background-color:green;margin-left:10px;margin-top:20px;">UNBLOCK</button>
    <?php endif; ?>
    </form>
    <button id="back-btn-i" style="margin-left:10px;margin-top:20px;" onclick="location.href='/admembers'">BACK</button><br>

    </div>
    <?php if(Session('error')): ?>
    <div class="alert">
        <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
        <strong>Warning! </strong><?php echo e(Session('error')); ?>

    </div>
    <?php endif; ?>
    <br><br>
    <table id="pro-tab">
        <tr><td colspan="5"><b>PROFILE</b></td></tr>
        <tr>
            <td>Name </td>
            <td><?php echo e($memreg->fullname); ?></td>
            <td rowspan="9"><image id="profileImage" src="<?php echo e(asset('profilepictures/'.$memprop->picture)); ?>" style="width:150px;height:150px;"><br></td>
        </tr>
        <tr>
            <td>DOB </td>
            <td><?php echo e($memreg->dob); ?></td>
        </tr>
        <tr>
            <td>Age</td>
            <td><?php echo e($memreg->age); ?></td>
        </tr>
        <tr>
            <td>Email</td>
            <td><?php echo e($memlog->email); ?></td>
        </tr>
        <tr>
            <td>Bio</td>
            <td><?php echo e($memprop->bio); ?></td>
        </tr>
        <tr>
            <td>Level</td>
            <td><?php echo e($memprop->level); ?></td>
        </tr>
        <tr>
            <td>Reports</td>
            <td><?php echo e($memreg->reports); ?></td>
        </tr>
        <tr>
            <td>Suspend</td>
            <td><?php echo e($memsus->suspend); ?></td>
        </tr>
        <tr>
            <td>Status</td>
            <?php if($memreg->status == 0): ?>
                <td style="color:red;"> Blocked </td>
            <?php elseif($memreg->status == 2): ?>
                <td style="color:lightgreen;"> Active </td>
            <?php else: ?>
                <td style="color:orange;"> Suspended </td>
            <?php endif; ?>
        </tr>
    </table><br><br>
    <table id="pro-tab">
        <tr>
            <th colspan="2">FOLLOWERS</th>
        </tr>
        <?php if(count($memfrnd) > 0): ?>
        <?php $__currentLoopData = $memfrnd; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($f->frnd->fullname); ?></td>
            <form action="<?php echo e(route('admempro',$f->friendid)); ?>" method="POST">
            <?php echo csrf_field(); ?>
                <td><button type="submit">VIEW</button></td>
            </form>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td><center><span style="color:red"><b>NONE</b></span></center></td>
        </tr>
        <?php endif; ?>
    </table><br><br>
    <table id="pro-tab">
        <tr>
            <th colspan="4">ORDERS</th>
        </tr>
        <tr>
            <th>Order ID</th>
            <th>Amount</th>
            <th>PLACED TIME</th>
            <th>Status</th>
        </tr>
        <?php if(count($memorders) > 0): ?>
        <?php $__currentLoopData = $memorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($o->orderid); ?></td>
            <td><?php echo e($o->paymentamt); ?></td>
            <td><?php echo e($o->placed_at); ?></td>
            <?php if($o->status==0): ?>
            <td style="color:lightgreen">Completed</td>
            <?php elseif($o->status==1): ?>
            <td style="color:orange">Pending</td>
            <?php else: ?>
            <td style="color:cyan">Processing</td>
            <?php endif; ?>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
        <tr>
            <td colspan="4"><center><span style="color:red"><b>NONE</b></span></center></td>
        </tr>
        <?php endif; ?>
    </table><br><br>
    <table id="pro-tab">
        <tr>
            <th colspan="7">POSTS</th>
        </tr>
        <tr>
            <th>Pic</th>
            <th>Caption</th>
            <th style="width:100px;">Upload Time</th>
            <th>Likes</th>
            <th>Comments</th>
            <th>Reports</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $mempost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><image id="posts" src="<?php echo e(asset('posts/'.$p->image)); ?>" style="width:100px;height:150px;"><br</td>
            <td><?php echo e($p->body); ?></td>
            <td><?php echo e($p->created_at); ?></td>
            <td>0</td>
            <td>0</td>
            <td>0</td>
            <td><button type="submit" style="background-color:red">DELETE</button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><br><br>
    </div>
</body><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/adMemProfile.blade.php ENDPATH**/ ?>