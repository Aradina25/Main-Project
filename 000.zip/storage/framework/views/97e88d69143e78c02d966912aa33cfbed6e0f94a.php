

<?php $__env->startSection('title','HOME'); ?>
<?php $__env->startSection('username',$user->fullname); ?>
<?php $__env->startSection('width',$width); ?>
<?php $__env->startSection('comptgoal',$challenge->completedgoal); ?>
<?php $__env->startSection('goal',$challenge->goal); ?>
<style>
    #sales-tab td:first-child:before{
    counter-increment: Serial;
    content:counter(Serial);
}
</style>
<?php $__env->startSection('content'); ?>
<div id="mid-view" class="child-element" style="width:750px;margin-top:3%;">
<h3>Current Sales</h3><br><br>
<table class="table" id="sales-tab" style="background-color:white;">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Item</th>
      <!-- <th scope="col">Customer</th> -->
      <th scope="col">Min Amount</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>
    </tr>
  </thead>
  <tbody>
    <?php ($i=1); ?>
    <?php $__currentLoopData = $store; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($i); ?></th>
      <td><?php echo e($store->btitle); ?> - <?php echo e($store->bauthor); ?></td>
      
      <td><?php echo e($store->minprice); ?></td>
      <?php if($store->status==0): ?>
      <td>Sold</td>
      <?php elseif($store->status==1): ?>
      <td>In store</td>
      <?php elseif($store->status==2): ?>
      <td>Biding Active</td>
      <?php else: ?>
      <td>Biding Requested</td>
      <?php endif; ?>
      <td>
        <div class="btn-group">
            <button type="button" class="btn btn-primary" onclick="location.href='<?php echo e(route('viewthrift',['accId'=>$store->bookid,'userid'=>$store->userid])); ?>'">
                View
            </button>
        </div>
      </td>
    </tr>
    <?php ($i=$i+1); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </tbody>
</table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('layouts.usertemp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\MainProject\Blounge\resources\views/thriftsales.blade.php ENDPATH**/ ?>